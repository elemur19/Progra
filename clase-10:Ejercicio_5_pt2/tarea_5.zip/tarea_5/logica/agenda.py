class Agenda:
    def __init__(self):
        self.contactos = []

    def cargar_contactos(self, contactos):
        self.contactos = contactos

    def agregar_contacto(self, contacto):
        self.contactos.append(contacto)

    def buscar_por_nombre(self, texto):
        texto = texto.lower()
        resultados = []

        for contacto in self.contactos:
            if texto in contacto.nombre.lower():
                resultados.append(contacto)

        return resultados

    def buscar_por_telefono(self, texto):
        texto = texto.lower()
        resultados = []

        for contacto in self.contactos:
            if texto in contacto.telefono.lower():
                resultados.append(contacto)

        return resultados

    def promedio_edad(self):
        if len(self.contactos) == 0:
            return 0

        suma = 0
        for contacto in self.contactos:
            suma += contacto.edad

        return suma / len(self.contactos)

    def mostrar_todos(self):
        return self.contactos