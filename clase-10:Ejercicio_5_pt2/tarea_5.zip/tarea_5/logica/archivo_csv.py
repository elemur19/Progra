import csv
from funciones.contacto import Contacto


def cargar_csv(ruta):
    contactos = []

    try:
        with open(ruta, "r", encoding="utf-8", newline="") as archivo:
            lector = csv.DictReader(archivo)

            for fila in lector:
                contactos.append(Contacto.from_dict(fila))

    except FileNotFoundError:
        return []

    return contactos


def guardar_csv(ruta, contactos):
    with open(ruta, "w", encoding="utf-8", newline="") as archivo:
        campos = ["nombre", "telefono", "email", "edad", "residencia"]
        escritor = csv.DictWriter(archivo, fieldnames=campos)

        escritor.writeheader()

        for contacto in contactos:
            escritor.writerow(contacto.to_dict())