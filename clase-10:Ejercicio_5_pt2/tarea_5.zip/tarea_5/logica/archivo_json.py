import json
from funciones.contacto import Contacto


def cargar_json(ruta):
    try:
        with open(ruta, "r", encoding="utf-8") as archivo:
            datos = json.load(archivo)

        contactos = []
        for item in datos:
            contactos.append(Contacto.from_dict(item))

        return contactos

    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        print("Error: el archivo JSON no tiene un formato válido.")
        return []


def guardar_json(ruta, contactos):
    datos = []

    for contacto in contactos:
        datos.append(contacto.to_dict())

    with open(ruta, "w", encoding="utf-8") as archivo:
        json.dump(datos, archivo, ensure_ascii=False, indent=4)