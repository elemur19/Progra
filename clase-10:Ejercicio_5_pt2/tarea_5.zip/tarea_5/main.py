from funciones.contacto import Contacto
from logica.agenda import Agenda
from logica.archivo_json import cargar_json, guardar_json
from logica.archivo_csv import cargar_csv, guardar_csv
from funciones.menu import mostrar_menu, mostrar_submenu_carga


def pedir_contacto():
    print("\n--- Agregar contacto ---")
    nombre = input("Nombre: ").strip()
    telefono = input("Teléfono: ").strip()
    email = input("Email: ").strip()

    while True:
        try:
            edad = int(input("Edad: ").strip())
            break
        except ValueError:
            print("Edad inválida. Debe ingresar un número entero.")

    residencia = input("Residencia: ").strip()

    return Contacto(nombre, telefono, email, edad, residencia)


def mostrar_resultados(lista):
    if len(lista) == 0:
        print("\nNo se encontraron resultados.")
        return

    print("\nResultados encontrados:")
    for i, contacto in enumerate(lista, start=1):
        print(f"\nContacto #{i}")
        print(contacto)


def main():
    agenda = Agenda()
    ruta_actual = None
    tipo_actual = None

    while True:
        mostrar_menu()
        opcion = input("\nSeleccione una opción: ").strip()

        if opcion == "1":
            mostrar_submenu_carga()
            subopcion = input("Seleccione una opción: ").strip()

            if subopcion == "1":
                ruta = input("Ingrese la ruta del archivo JSON: ").strip()
                contactos = cargar_json(ruta)
                agenda.cargar_contactos(contactos)
                ruta_actual = ruta
                tipo_actual = "json"
                print(f"\nSe cargaron {len(contactos)} contactos desde JSON.")
                input("\nPresione ENTER para volver al menú...")

            elif subopcion == "2":
                ruta = input("Ingrese la ruta del archivo CSV: ").strip()
                contactos = cargar_csv(ruta)
                agenda.cargar_contactos(contactos)
                ruta_actual = ruta
                tipo_actual = "csv"
                print(f"\nSe cargaron {len(contactos)} contactos desde CSV.")

            else:
                print("Opción inválida.")

        elif opcion == "2":
            if ruta_actual is None:
                print("\nPrimero debe cargar un archivo.")
                continue

            nuevo_contacto = pedir_contacto()
            agenda.agregar_contacto(nuevo_contacto)

            if tipo_actual == "json":
                guardar_json(ruta_actual, agenda.contactos)
            elif tipo_actual == "csv":
                guardar_csv(ruta_actual, agenda.contactos)

            print("\nContacto agregado y guardado correctamente.")
            input("\nPresione ENTER para volver al menú...")

        elif opcion == "3":
            texto = input("\nIngrese el nombre o parte del nombre a buscar: ").strip()
            resultados = agenda.buscar_por_nombre(texto)
            mostrar_resultados(resultados)
            input("\nPresione ENTER para volver al menú...")

        elif opcion == "4":
            texto = input("\nIngrese el teléfono o parte del teléfono a buscar: ").strip()
            resultados = agenda.buscar_por_telefono(texto)
            mostrar_resultados(resultados)
            input("\nPresione ENTER para volver al menú...")

        elif opcion == "5":
            promedio = agenda.promedio_edad()
            print(f"\nPromedio de edad: {promedio:.2f}")
            input("\nPresione ENTER para volver al menú...")

        elif opcion == "6":
            contactos = agenda.mostrar_todos()
            mostrar_resultados(contactos)
            input("\nPresione ENTER para volver al menú...")

        elif opcion == "7":
            print("\nSaliendo del programa...")
            break

        else:
            print("\nOpción inválida. Intente de nuevo.")


if __name__ == "__main__":
    main()