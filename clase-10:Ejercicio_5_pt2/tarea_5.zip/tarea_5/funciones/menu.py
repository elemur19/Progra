def mostrar_menu():
    print("======================================")
    print("          SHERLOCK HOLMES  ")
    print("        AGENDA DE CONTACTOS   ")
    print("======================================")
    print("1. Cargar agenda")
    print("2. Agregar contacto")
    print("3. Buscar contacto por nombre")
    print("4. Buscar contacto por teléfono")
    print("5. Mostrar promedio de edad")
    print("6. Mostrar todos los contactos")
    print("7. Salir")


def mostrar_submenu_carga():
    print("\n--- Cargar agenda ---")
    print("1. Cargar desde archivo JSON")
    print("2. Cargar desde archivo CSV")