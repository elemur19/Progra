class Contacto:
    def __init__(self, nombre, telefono, email, edad, residencia):
        self.nombre = nombre
        self.telefono = telefono
        self.email = email
        self.edad = edad
        self.residencia = residencia

    def to_dict(self):
        return {
            "nombre": self.nombre,
            "telefono": self.telefono,
            "email": self.email,
            "edad": self.edad,
            "residencia": self.residencia
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            data["nombre"],
            data["telefono"],
            data["email"],
            int(data["edad"]),
            data["residencia"]
        )

    def __str__(self):
        return (
            f"Nombre: {self.nombre}\n"
            f"Teléfono: {self.telefono}\n"
            f"Email: {self.email}\n"
            f"Edad: {self.edad}\n"
            f"Residencia: {self.residencia}\n"
        )